<footer class="blockquote-footer" style="text-align: center;">
    <div class="copyright">
        &copy; Desenvolvido por <a target="_blank" href="https://www.linkedin.com/in/maxsandro-sarat-ribeiro-704ab4a7">Maxsandro Sarat</a> 2020. Todos os direitos reservados.
    </div>
</footer>